//
// Created by lbx on 2021/9/5.
//

#ifndef KICKTREE_V0_1_TOOLS_H
#define KICKTREE_V0_1_TOOLS_H
#include "KickTree.h"

class Tools {
public:
    void LevelTravse(KickTreeNode *root);
};

#endif //KICKTREE_V0_1_TOOLS_H
