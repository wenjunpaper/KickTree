Usage:
    ./main [-r ruleFile] [-p traceFile] [-b binth] [-bit numBits] [-t maxTree] [-l maxDepth]