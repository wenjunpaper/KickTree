"""Package with classes for processing data from files."""
