"""Package with classes for printing output data to different directions."""
