"""Package with classes for formatting different types of values to specified form."""
