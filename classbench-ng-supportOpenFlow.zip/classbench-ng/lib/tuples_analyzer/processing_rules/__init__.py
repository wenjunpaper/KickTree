"""Package with classes for processing filter rules from filter set file into generator of FilterRule instances."""
