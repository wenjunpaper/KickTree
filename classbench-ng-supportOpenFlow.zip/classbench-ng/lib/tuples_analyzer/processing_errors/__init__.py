"""Package with classes to correctly end program while error occurred and for printing error logs to stderr."""
